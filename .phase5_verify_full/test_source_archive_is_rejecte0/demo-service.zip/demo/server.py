print('mcp')
